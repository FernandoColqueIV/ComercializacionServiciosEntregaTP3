<?php
    session_start();
    include_once 'conexion.php'; // Evita múltiples inclusiones

    // 1️⃣ Verificar login
    if (!isset($_SESSION['id'])) {
        header("Location: Usuario/login.php");
        exit();
    }

    // ID del usuario logueado
    $id_usuario_actual = (int)$_SESSION['id'];

    // --- PROCESAR FORMULARIO (POST) ---
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Verificar que venga el ID del producto
        if (!isset($_POST['id_producto']) || empty($_POST['id_producto'])) {
            echo "Error: No se proporcionó ID de producto (POST).";
            exit();
        }

        // ✅ Recolectar datos
        $id_producto = (int)$_POST['id_producto'];
        $titulo = trim($_POST['titulo']);
        $descripcion = trim($_POST['descripcion']);
        $marca = trim($_POST['marca']);
        $modelo = trim($_POST['modelo']);
        $ancho = (int)$_POST['ancho'];
        $perfil = (int)$_POST['perfil'];
        $diametro = (int)$_POST['diametro'];
        $temporada = trim($_POST['temporada']);
        $condicion = trim($_POST['condicion']);
        $cantidad = (int)$_POST['cantidad'];
        $precio = (float)$_POST['precio'];

        // ✅ Verificar existencia y permisos
        $sql_check = "SELECT imagen, id_usuario FROM productos WHERE id = ?";
        $stmt_check = $conexion->prepare($sql_check);
        $stmt_check->bind_param("i", $id_producto);
        $stmt_check->execute();
        $resultado_check = $stmt_check->get_result();

        if ($resultado_check->num_rows === 0) {
            echo "Error: El producto no existe.";
            exit();
        }

        $producto_actual = $resultado_check->fetch_assoc();

        if ($producto_actual['id_usuario'] != $id_usuario_actual) {
            echo "Error: No tienes permiso para editar este producto.";
            exit();
        }

        $rutaDestino = $producto_actual['imagen']; // Ruta por defecto (imagen anterior)
        $stmt_check->close();

        // ✅ Subida de nueva imagen (opcional)
        $carpeta = "uploads/";
        if (!file_exists($carpeta)) mkdir($carpeta, 0777, true);

        if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            $nombreImagen = uniqid() . "_" . basename($_FILES['imagen']['name']);
            $nuevaRutaDestino = $carpeta . $nombreImagen;

            if (move_uploaded_file($_FILES['imagen']['tmp_name'], $nuevaRutaDestino)) {
                // Borrar la anterior si no es la imagen por defecto
                $imagen_antigua = $producto_actual['imagen'];
                if (file_exists($imagen_antigua) && basename($imagen_antigua) !== 'default.jpg') {
                    unlink($imagen_antigua);
                }
                $rutaDestino = $nuevaRutaDestino;
            } else {
                echo "Error al subir la nueva imagen.";
                exit();
            }
        }

        // ✅ Actualizar producto
        $sql_update = "UPDATE productos SET 
            titulo = ?, descripcion = ?, marca = ?, modelo = ?, 
            ancho = ?, perfil = ?, diametro = ?, temporada = ?, 
            condicion = ?, cantidad = ?, precio_unitario = ?, imagen = ?
            WHERE id = ? AND id_usuario = ?";

        $stmt_update = $conexion->prepare($sql_update);

        if (!$stmt_update) {
            echo "Error al preparar UPDATE: " . $conexion->error;
            exit();
        }

        $stmt_update->bind_param(
            "ssssiiisssdsii",
            $titulo, $descripcion, $marca, $modelo,
            $ancho, $perfil, $diametro, $temporada,
            $condicion, $cantidad, $precio, $rutaDestino,
            $id_producto, $id_usuario_actual
        );

        if ($stmt_update->execute()) {
            header("Location: index.php?edit=success");
            exit();
        } else {
            echo "Error al actualizar: " . $stmt_update->error;
        }

        $stmt_update->close();
        $conexion->close();
        exit();
    }

    // --- MOSTRAR FORMULARIO (GET) ---
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "Error: No se proporcionó ID de producto (GET).";
        exit();
    }

    $id_producto = (int)$_GET['id'];

    // ✅ Cargar producto existente
    $sql_get = "SELECT * FROM productos WHERE id = ? AND id_usuario = ?";
    $stmt_get = $conexion->prepare($sql_get);
    $stmt_get->bind_param("ii", $id_producto, $id_usuario_actual);
    $stmt_get->execute();
    $resultado = $stmt_get->get_result();

    if ($resultado->num_rows === 0) {
        echo "Error: Producto no encontrado o sin permisos.";
        exit();
    }

    $producto = $resultado->fetch_assoc();
    $stmt_get->close();
    $conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Publicación</title>
    <link rel="stylesheet" href="css/styles_publicar.css">
</head>
<body>
<header>
    <a href="index.php">NeuAndes</a>
    <nav>
        <a href="about.html">Sobre Nosotros</a>
        <a href="Usuario/logout.php" class="logout-btn">Cerrar Sesión</a>
    </nav>
</header>

<section class="section-publicar">
    <div class="form-container">
        <h2>Editar Publicación de Neumático</h2>

        <form action="editar_producto.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_producto" value="<?php echo htmlspecialchars($producto['id']); ?>">

            <label for="titulo">Título *</label>
            <input type="text" name="titulo" id="titulo" required value="<?php echo htmlspecialchars($producto['titulo']); ?>">

            <label for="descripcion">Descripción</label>
            <textarea name="descripcion" id="descripcion"><?php echo htmlspecialchars($producto['descripcion']); ?></textarea>

            <div class="row">
                <div class="field">
                    <label for="marca">Marca *</label>
                    <input type="text" name="marca" id="marca" required value="<?php echo htmlspecialchars($producto['marca']); ?>">
                </div>
                <div class="field">
                    <label for="modelo">Modelo *</label>
                    <input type="text" name="modelo" id="modelo" required value="<?php echo htmlspecialchars($producto['modelo']); ?>">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label for="ancho">Ancho *</label>
                    <input type="number" name="ancho" id="ancho" required value="<?php echo (int)$producto['ancho']; ?>">
                </div>
                <div class="field">
                    <label for="perfil">Perfil *</label>
                    <input type="number" name="perfil" id="perfil" required value="<?php echo (int)$producto['perfil']; ?>">
                </div>
                <div class="field">
                    <label for="diametro">Diámetro *</label>
                    <input type="number" name="diametro" id="diametro" required value="<?php echo (int)$producto['diametro']; ?>">
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label for="temporada">Temporada *</label>
                    <select name="temporada" id="temporada" required>
                        <option value="">Selecciona temporada</option>
                        <option value="Verano" <?php if ($producto['temporada'] == 'Verano') echo 'selected'; ?>>Verano</option>
                        <option value="Invierno" <?php if ($producto['temporada'] == 'Invierno') echo 'selected'; ?>>Invierno</option>
                        <option value="Todo el año" <?php if ($producto['temporada'] == 'Todo el año') echo 'selected'; ?>>Todo el año</option>
                    </select>
                </div>
                <div class="field">
                    <label for="condicion">Condición *</label>
                    <select name="condicion" id="condicion" required>
                        <option value="">Selecciona condición</option>
                        <option value="Nuevo" <?php if ($producto['condicion'] == 'Nuevo') echo 'selected'; ?>>Nuevo</option>
                        <option value="Usado" <?php if ($producto['condicion'] == 'Usado') echo 'selected'; ?>>Usado</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="field">
                    <label for="cantidad">Cantidad *</label>
                    <input type="number" name="cantidad" id="cantidad" required value="<?php echo (int)$producto['cantidad']; ?>">
                </div>
                <div class="field">
                    <label for="precio">Precio (por unidad) *</label>
                    <input type="number" step="0.01" name="precio" id="precio" required value="<?php echo (float)$producto['precio_unitario']; ?>">
                </div>
            </div>

            <label for="imagen">Cambiar Imagen (Opcional)</label>
            <p>Imagen actual:</p>
            <img src="<?php echo htmlspecialchars($producto['imagen']); ?>" alt="Imagen actual" style="max-width:150px;margin-bottom:10px;">
            <input type="file" name="imagen" id="imagen" accept="image/*">

            <div class="buttons">
                <button type="submit" class="btn-primary">Guardar Cambios</button>
                <button type="button" class="btn-secondary" onclick="window.location.href='index.php'">Cancelar</button>
            </div>
        </form>
    </div>
</section>
</body>
</html>
