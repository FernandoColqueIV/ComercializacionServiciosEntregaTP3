document.addEventListener("DOMContentLoaded", () => {
  const btnAgregar = document.getElementById("btnAgregar");
  const formProducto = document.getElementById("formProducto");
  const btnGuardar = document.getElementById("btnGuardar");

  // Mostrar el formulario
  btnAgregar.addEventListener("click", () => {
    formProducto.classList.toggle("hidden");
  });

  // Guardar el producto en localStorage
  btnGuardar.addEventListener("click", () => {
    const nombre = document.getElementById("nombre").value;
    const descripcion = document.getElementById("descripcion").value;
    const precio = document.getElementById("precio").value;

    if (!nombre || !precio) {
      alert("El nombre y precio son obligatorios");
      return;
    }

    // Crear objeto producto
    const producto = { nombre, descripcion, precio };

    // Obtener productos existentes o iniciar array vacío
    const productos = JSON.parse(localStorage.getItem("productos")) || [];

    // Agregar nuevo producto
    productos.push(producto);

    // Guardar de nuevo
    localStorage.setItem("productos", JSON.stringify(productos));

    alert("Producto guardado correctamente");

    // Limpiar formulario
    document.getElementById("nombre").value = "";
    document.getElementById("descripcion").value = "";
    document.getElementById("precio").value = "";
    formProducto.classList.add("hidden");
  });
});
