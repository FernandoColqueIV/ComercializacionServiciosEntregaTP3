<?php /*<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Publicar Neumático</title>
        <link rel="stylesheet" href="css/styles_publicar.css">
    </head>

    <body>
        <header>
            <a href="../index.html">NeuAndes</a>

            <nav>                
                <a href="about.html">Sobre Nosotros</a>
                <a href="Usuario/logout.php" class="logout-btn">Cerrar Sesion</a>
            </nav>
        </header>

        <section class="section-publicar">
            <div class="form-container">
                <h2>Nueva Publicación de Neumático</h2>

                <form action="publicar.php" method="POST">
                    <label for="titulo">Título *</label>
                    <input type="text" id="titulo" placeholder="Ej: Neumáticos Michelin Pilot Sport 4">

                    <label for="descripcion">Descripción</label>
                    <textarea id="descripcion" placeholder="Describe el estado, características especiales, etc."></textarea>

                    <div class="row">
                        <div class="field">
                            <label for="marca">Marca *</label>
                            <input type="text" id="marca" placeholder="Ej: Michelin">
                        </div>
                        <div class="field">
                            <label for="modelo">Modelo *</label>
                            <input type="text" id="modelo" placeholder="Ej: Pilot Sport 4">
                        </div>
                    </div>

                    <div class="row">
                        <div class="field">
                            <label for="ancho">Ancho (mm) *</label>
                            <input type="number" id="ancho" placeholder="205">
                        </div>
                        <div class="field">
                            <label for="perfil">Perfil *</label>
                            <input type="number" id="perfil" placeholder="55">
                        </div>
                        <div class="field">
                            <label for="diametro">Diámetro (") *</label>
                            <input type="number" id="diametro" placeholder="16">
                        </div>
                    </div>

                    <div class="row">
                        <div class="field">
                            <label for="temporada">Temporada *</label>
                            <select id="temporada">
                                <option>Selecciona temporada</option>
                                <option>Verano</option>
                                <option>Invierno</option>
                                <option>Todo el año</option>
                            </select>
                        </div>
                        <div class="field">
                            <label for="condicion">Condición *</label>
                            <select id="condicion">
                                <option>Selecciona condición</option>
                                <option>Nuevo</option>
                                <option>Usado</option>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="field">
                            <label for="cantidad">Cantidad *</label>
                            <input type="number" id="cantidad" placeholder="4">
                        </div>
                        <div class="field">
                            <label for="precio">Precio (por unidad) *</label>
                            <input type="number" id="precio" placeholder="50000">
                        </div>
                    </div>

                    <label for="url">URL de Imagen</label>
                    <input type="file" id="url" accept="image/*" placeholder="https://ejemplo.com/imagen.jpg">

                    <div class="buttons">
                        <button type="submit" class="btn-primary">Crear Publicación</button>
                        <button type="button" class="btn-secondary">Cancelar</button>
                    </div>
                </form>
            </div>
        </section>

    </body>
</html>
/*
session_start();
include 'conexion.php'; // $conexion debe ser un objeto mysqli
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Verificar login
    if (!isset($_SESSION['id'])) {
        echo "Error: no hay usuario logueado.";
        exit();
    }

    // 2. Obtener ID de sesión
    

    // 3. Recolectar datos del formulario
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $ancho = (int)$_POST['ancho']; // Convertir a entero
    $perfil = (int)$_POST['perfil']; // Convertir a entero
    $diametro = (int)$_POST['diametro']; // Convertir a entero
    $temporada = $_POST['temporada'];
    $condicion = $_POST['condicion'];
    $cantidad = (int)$_POST['cantidad']; // Convertir a entero
    $precio = (float)$_POST['precio']; // Convertir a decimal/flotante
    $id_usuario = (int)$_SESSION['id']; // Aseguramos que sea un entero
    $imagen = $_POST['url'];
    $fecha_creacion = date("Y-m-d");

    // Carpeta donde se guardarán las imágenes
    $carpeta = "uploads/";
    if (!file_exists($carpeta)) {
        mkdir($carpeta, 0777, true);
    }

    // Procesar la imagen
    $nombreImagen = $_FILES['imagen']['name'];
    $rutaTemporal = $_FILES['imagen']['tmp_name'];
    $rutaDestino = $carpeta . basename($nombreImagen);

    // 4. Preparar la consulta SQL (Forma Segura)
    // Usamos '?' como marcadores de posición
    $sql = "INSERT INTO productos (
                titulo, descripcion, marca, modelo, 
                ancho, perfil, diametro, temporada, 
                condicion, cantidad, precio_unitario, imagen, id_usuario, fecha_creacion
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    // 5. Preparar la sentencia
    $stmt = $conexion->prepare($sql);

    if ($stmt === false) {
        echo "Error al preparar la consulta: " . $conexion->error;
        exit();
    }

    // 6. Vincular los parámetros (bind_param)
    // 's' = string, 'i' = integer, 'd' = double (para el precio)
    // El orden y tipo DEBEN coincidir con los '?'
    $stmt->bind_param(
        "ssssiiisssdsis", 
        $titulo,
        $descripcion,
        $marca,
        $modelo,
        $ancho,
        $perfil,
        $diametro,
        $temporada,
        $condicion,
        $cantidad,
        $precio,
        $imagen,
        $id_usuario,
        $fecha_creacion
    );

    // 7. Ejecutar la consulta
    if ($stmt->execute()) {
        header("Location: index.php"); // Éxito, redirigir
        exit();
    } else {
        echo "Error al guardar en la base: " . $stmt->error;
    }

    // 8. Cerrar
    $stmt->close();
    $conexion->close();
}*/
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Publicar Neumático</title>
  <link rel="stylesheet" href="css/styles_publicar.css">
</head>

<body>
  <header>
    <a href="index.php">NeuAndes</a>
    <nav>                
      <a href="about.html">Sobre Nosotros</a>
      <a href="Usuario/logout.php" class="logout-btn">Cerrar Sesión</a>
    </nav>
  </header>

  <section class="section-publicar">
    <div class="form-container">
      <h2>Nueva Publicación de Neumático</h2>

      <!-- IMPORTANTE: enctype para subir archivos -->
      <form action="publicar.php" method="POST" enctype="multipart/form-data">
        <label for="titulo">Título *</label>
        <input type="text" name="titulo" id="titulo" placeholder="Ej: Neumáticos Michelin Pilot Sport 4" required>

        <label for="descripcion">Descripción</label>
        <textarea name="descripcion" id="descripcion" placeholder="Describe el estado, características especiales, etc."></textarea>

        <div class="row">
          <div class="field">
            <label for="marca">Marca *</label>
            <input type="text" name="marca" id="marca" required>
          </div>
          <div class="field">
            <label for="modelo">Modelo *</label>
            <input type="text" name="modelo" id="modelo" required>
          </div>
        </div>

        <div class="row">
          <div class="field">
            <label for="ancho">Ancho (mm) *</label>
            <input type="number" name="ancho" id="ancho" required>
          </div>
          <div class="field">
            <label for="perfil">Perfil *</label>
            <input type="number" name="perfil" id="perfil" required>
          </div>
          <div class="field">
            <label for="diametro">Diámetro (") *</label>
            <input type="number" name="diametro" id="diametro" required>
          </div>
        </div>

        <div class="row">
          <div class="field">
            <label for="temporada">Temporada *</label>
            <select name="temporada" id="temporada" required>
              <option value="">Selecciona temporada</option>
              <option>Verano</option>
              <option>Invierno</option>
              <option>Todo el año</option>
            </select>
          </div>
          <div class="field">
            <label for="condicion">Condición *</label>
            <select name="condicion" id="condicion" required>
              <option value="">Selecciona condición</option>
              <option>Nuevo</option>
              <option>Usado</option>
            </select>
          </div>
        </div>

        <div class="row">
          <div class="field">
            <label for="cantidad">Cantidad *</label>
            <input type="number" name="cantidad" id="cantidad" required>
          </div>
          <div class="field">
            <label for="precio">Precio (por unidad) *</label>
            <input type="number" name="precio" id="precio" required>
          </div>
        </div>

        <label for="imagen">Imagen *</label>
        <input type="file" name="imagen" id="imagen" accept="image/*" required>

        <div class="buttons">
          <button type="submit" class="btn-primary">Crear Publicación</button>
          <button type="button" class="btn-secondary">Cancelar</button>
        </div>
      </form>
    </div>
  </section>
</body>
</html>


<?php
session_start();
include 'conexion.php'; // conexión a la BD

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Verificar login
    if (!isset($_SESSION['id'])) {
        echo "Error: no hay usuario logueado.";
        exit();
    }

    // 2. Recolectar datos del formulario
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $ancho = (int)$_POST['ancho'];
    $perfil = (int)$_POST['perfil'];
    $diametro = (int)$_POST['diametro'];
    $temporada = $_POST['temporada'];
    $condicion = $_POST['condicion'];
    $cantidad = (int)$_POST['cantidad'];
    $precio = (float)$_POST['precio'];
    $id_usuario = (int)$_SESSION['id'];
    $fecha_creacion = date("Y-m-d");

    // 3. Subida de imagen
    $carpeta = "uploads/";
    if (!file_exists($carpeta)) mkdir($carpeta, 0777, true);

    $rutaDestino = null;

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == UPLOAD_ERR_OK) {
        $nombreImagen = uniqid() . "_" . basename($_FILES['imagen']['name']);
        $rutaDestino = $carpeta . $nombreImagen;

        if (!move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
            echo "Error al mover la imagen. Verifica los permisos de la carpeta 'uploads'.";
            exit();
        }
    } else {
        echo "Error al subir la imagen. Código de error: " . $_FILES['imagen']['error'];
        exit();
    }

    // 4. Guardar en la BD
    $sql = "INSERT INTO productos (
                titulo, descripcion, marca, modelo, 
                ancho, perfil, diametro, temporada, 
                condicion, cantidad, precio_unitario, 
                imagen, id_usuario, fecha_creacion
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        echo "Error al preparar la consulta: " . $conexion->error;
        exit();
    }

    $stmt->bind_param(
        "ssssiiisssdsis",
        $titulo,
        $descripcion,
        $marca,
        $modelo,
        $ancho,
        $perfil,
        $diametro,
        $temporada,
        $condicion,
        $cantidad,
        $precio,
        $rutaDestino,
        $id_usuario,
        $fecha_creacion
    );

    if ($stmt->execute()) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error al guardar en la base de datos: " . $stmt->error;
    }

    $stmt->close();
    $conexion->close();
}
?>

