document.addEventListener("DOMContentLoaded", () => {

  let cart = [];

  // Click en "Al Carrito"
  document.querySelectorAll('.btn-add-cart').forEach(btn => {
    btn.addEventListener('click', e => {
      const item = e.target.closest('.item');
      const title = item.dataset.title;
      const price = parseFloat(item.dataset.price);

      const existing = cart.find(p => p.title === title);
      if (existing) existing.quantity++;
      else cart.push({ title, price, quantity: 1 });

      //openCart();
      renderCart();
    });
  });

    //Abrir carrito
    document.getElementById('open-cart-btn').addEventListener('click', () => {
        openCart();
    });

  // Mostrar productos del carrito
  function renderCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';

    let total = 0;
    cart.forEach((p, i) => {
      total += p.price * p.quantity;
      const div = document.createElement('div');
      div.classList.add('cart-item');
      div.innerHTML = `
        <span>${p.title}</span>
        <span>x${p.quantity}</span>
        <span>$${(p.price * p.quantity).toLocaleString()}</span>
        <button class="btn-remove" data-index="${i}">X</button>
      `;
      cartItems.appendChild(div);
    });
    document.getElementById('total-amount').textContent = total.toLocaleString();

    // Reasignar eventos de eliminación
    document.querySelectorAll('.btn-remove').forEach(btn => {
      btn.addEventListener('click', e => {
        const i = e.target.dataset.index;
        removeFromCart(i);
      });
    });
  }

  // Eliminar producto
  function removeFromCart(index) {
    cart.splice(index, 1);
    renderCart();
  }

  // Abrir carrito
  function openCart() {
    document.getElementById('cart-modal').style.display = 'block';
  }

  // Cerrar carrito
  document.querySelector('.close-cart').addEventListener('click', () => {
    document.getElementById('cart-modal').style.display = 'none';
  });

  // Finalizar compra
  document.getElementById('finalizar-compra').addEventListener('click', () => {
    if (cart.length === 0) return alert('Tu carrito está vacío.');
    let resumen = 'Resumen de compra:\n\n';
    cart.forEach(p => resumen += `${p.title} x${p.quantity} = $${(p.price * p.quantity).toLocaleString()}\n`);
    const total = cart.reduce((sum, p) => sum + p.price * p.quantity, 0);
    resumen += `\nTotal a pagar: $${total.toLocaleString()}`;
    alert(resumen);
  });

});