<?php 
    session_start();
    include 'conexion.php';
?>   

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <title>NeuAndes</title>
</head>
<body>
    <header>
        <a href="index.php">
            <img src="uploads/logo.jpeg" alt="Logo" style="width: 80px;">
        </a>

        <nav>
           
            <a href="about.html">Sobre Nosotros</a>

            <?php if (isset($_SESSION['id'])): ?>

                <?php 
                   
                    $usuario = $_SESSION['tipo'];

                    if ($usuario == "vendedor"){
                        echo '<a href="publicar.php" class="btn-vendedor">Crear Producto</a>';
                    }

                ?>


                <a href="Usuario/logout.php" class="logout-btn">Cerrar Sesión</a>
                
                
            <?php else: ?>
                <a href="Usuario/login.php" class="login-btn">Iniciar Sesión</a>
            <?php endif; ?>
        </nav>
    </header>

        <section>

            <div class="table">
                <div class="column">
                    <h1>
                        El Marketplace de <br> 
                        Neumaticos mas <br>
                        Confiable <br>
                    </h1>

                    <br>

                    <h3>
                        Compra y vende neumaticos de calidad. Conectamos compradora y
                        vendedores en una plataforma segura y facil de usar.
                    </h3>
                    
                    <br>

                    
                    <?php
                        if (isset($_SESSION['id'])){
                            
                           if($usuario == "vendedor"){
                                echo '<a href="indexcantcompras.php" class="boton azul">Ver Neumáticos</a>';
                                echo '<a href="publicar.php" class="boton gris">Empezar a Vender</a>';
                           }
                           else{
                                echo '<a href="indexcantcompras.php" class="boton azul">Ver Neumáticos</a>';
                                echo '<a href="Usuario/index.php" class="boton gris">Empezar a Vender</a>';
                           }

                        }
                        else{
                            echo '<a href="indexcantcompras.php" class="boton azul">Ver Neumáticos</a>';
                            echo '<a href="Usuario/index.php" class="boton gris">Empezar a Vender</a>';
                        }

                    ?>

                   

                </div>                

                <div class="column">
                    <img src="uploads/neumatico-home.jpg" alt="">
                </div>
            </div>         

        </section>

        <section>
            <h2>¿Por qué elegir NeuAndes?</h2>
            <div class="table">
                <div class="column">
                    Compra Segura
                </div>

                <div class="column">
                    Busqueda Rapida
                </div>

                <div class="column">
                    Comunidad Activa
                </div>

            </div>
        </section>

        <section class="cta-section">
            <h4>¿Listo para comenzar?</h4>
            <p>Unite a nuestra comunidad y encontrá los mejores neumáticos del mercado</p>
            <a href="indexcantcompras.php" class="boton azul">Explorar Marketplace</a>
        </section>


       <footer>
            <div class="footer-container">
                <div class="footer-column">
                    <h3>NeuAndes</h3>
                    <p>
                        El marketplace de neumáticos más confiable. Conectamos compradores y vendedores
                        en una plataforma segura.
                    </p>
                </div>

                <div class="footer-column">
                    <h4>Enlaces Rápidos</h4>
                    <ul>
                        <li><a href="/">Inicio</a></li>
                        <li><a href="">Marketplace</a></li>
                        <li><a href="">Sobre Nosotros</a></li>
                        <li><a href="">Iniciar Sesión</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h4>Contacto</h4>
                    <ul>
                        <li><a href="mailto:contacto@neuandes.com">contacto@neuandes.com</a></li>
                        <li><p>+54 9 261 123-4567</p></li>
                        <li><span>Calle Principal 123, Ciudad, País</span></li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 NeuAndes. Todos los derechos reservados.</p>
            </div>
        </footer>

    </body>

</html>
