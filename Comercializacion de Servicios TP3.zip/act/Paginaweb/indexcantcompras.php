<?php
    session_start();
    include 'conexion.php';

    // Verificamos si el usuario está logueado
    $idUsuarioSesion = $_SESSION['id'] ?? null;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <script src="https://sdk.mercadopago.com/js/v2"></script>
    <link rel="stylesheet" href="css/styles_cantCompras.css" />
    <title>Tienda</title>
</head>
<body>
   
<header>
        <a href="index.php">
            <img src="uploads/logo.jpeg" alt="Logo" style="width: 80px;">
        </a>

        <nav>
           
            

            <?php if (isset($_SESSION['id'])): ?>

                <?php 
                    $usuario = $_SESSION['tipo'];

                    if($usuario == "comprador"){
                        echo ' <button id="open-cart-btn" class="cart-btn">🛒</button>';
                    }

                ?>

                <a href="about.html">Sobre Nosotros</a>
                <a href="Usuario/logout.php" class="logout-btn">Cerrar Sesión</a>
                
                
                
            <?php else: ?>
                <a href="Usuario/login.php" class="login-btn">Iniciar Sesión</a>
                <a href="about.html">Sobre Nosotros</a>
            <?php endif; ?>
        </nav>
    </header>

    


    <div id="cart-modal" class="cart-modal">
        <div class="cart-content">
            <span class="close-cart">&times;</span>
            <h2>Tu Carrito</h2>
            <div id="cart-items"></div>
            <h3>Total: $<span id="total-amount">0</span></h3>

            


            <button id="finalizar-compra">Finalizar Compra</button>
            
        </div>
    </div>

    <!--<div class="filters-container">
        <h2>Filtros</h2>
        <div class="filter-group">
            <label>Marca</label>
            <input type="text" placeholder="Buscar marca..." />
        </div>
        <div class="filter-group">
            <label>Temporada</label>
            <select>
                <option>Todas</option>
                <option>Verano</option>
                <option>Invierno</option>
            </select>
        </div>
        <div class="filter-group">
            <label>Condición</label>
            <select>
                <option>Todas</option>
                <option>Nuevo</option>
                <option>Usado</option>
            </select>
        </div>
        <div class="filter-group">
            <label>Ancho (mm)</label>
            <input type="text" placeholder="Ej: 205" />
        </div>
        <div class="filter-group">
            <label>Diámetro (pulgadas)</label>
            <input type="text" placeholder="Ej: 16" />
        </div>
        <div class="filter-group">
            <label>Precio Mínimo</label>
            <input type="text" placeholder="$0" />
        </div>
        <div class="filter-group">
            <label>Precio Máximo</label>
            <input type="text" placeholder="$999999" />
        </div>

        <button>BUSCAR</button>
        <button class="clear-filters">Limpiar</button>
        
    </div>
    -->

    <form action="indexcantcompras.php" method="GET" class="filters-container">
        <h2>Filtros</h2>

        <div class="filter-group">
            <label for="marca">Marca</label>
            <input type="text" id="marca" name="marca" placeholder="Buscar marca..." />
        </div>

        <div class="filter-group">
            <label for="temporada">Temporada</label>
            <select id="temporada" name="temporada">
                <option value="">Todas</option>
                <option value="verano">Verano</option>
                <option value="invierno">Invierno</option>
            </select>
        </div>

        <div class="filter-group">
            <label for="condicion">Condición</label>
            <select id="condicion" name="condicion">
                <option value="">Todas</option>
                <option value="nuevo">Nuevo</option>
                <option value="usado">Usado</option>
            </select>
        </div>

        <div class="filter-group">
            <label for="ancho">Ancho (mm)</label>
            <input type="text" id="ancho" name="ancho" placeholder="Ej: 205" />
        </div>

        <div class="filter-group">
            <label for="diametro">Diámetro (pulgadas)</label>
            <input type="text" id="diametro" name="diametro" placeholder="Ej: 16" />
        </div>

        <div class="filter-group">
            <label for="precio_min">Precio Mínimo</label>
            <input type="text" id="precio_min" name="precio_min" placeholder="$0" />
        </div>

        <div class="filter-group">
            <label for="precio_max">Precio Máximo</label>
            <input type="text" id="precio_max" name="precio_max" placeholder="$999999" />
        </div>

        <div class="filter-buttons">
            <button type="submit" class="clear-filters" name="buscar">BUSCAR</button>
            <br>
            <br>
            <button type="reset" class="clear-filters">Limpiar</button>
        </div>
    </form>

    

    <div class="container-items">
        <?php            

            // Si se hizo clic en "BUSCAR"
            if (isset($_GET['buscar'])) {
                // Capturar valores de los filtros
                $marca = $_GET['marca'] ?? '';
                $temporada = $_GET['temporada'] ?? '';
                $condicion = $_GET['condicion'] ?? '';
                $ancho = $_GET['ancho'] ?? '';
                $diametro = $_GET['diametro'] ?? '';
                $precio_min = $_GET['precio_min'] ?? '';
                $precio_max = $_GET['precio_max'] ?? '';

                // Base de la consulta
                $sql = "SELECT * FROM productos WHERE 1=1";

                // Agregar condiciones dinámicas según los filtros
                if (!empty($marca)) {
                    $sql .= " AND marca LIKE '%" . $conexion->real_escape_string($marca) . "%'";
                }

                if (!empty($temporada)) {
                    $sql .= " AND temporada = '" . $conexion->real_escape_string($temporada) . "'";
                }

                if (!empty($condicion)) {
                    $sql .= " AND condicion = '" . $conexion->real_escape_string($condicion) . "'";
                }

                if (!empty($ancho)) {
                    $sql .= " AND ancho = '" . $conexion->real_escape_string($ancho) . "'";
                }

                if (!empty($diametro)) {
                    $sql .= " AND diametro = '" . $conexion->real_escape_string($diametro) . "'";
                }

                if (!empty($precio_min)) {
                    $sql .= " AND precio_unitario >= " . floatval($precio_min);
                }

                if (!empty($precio_max)) {
                    $sql .= " AND precio_unitario <= " . floatval($precio_max);
                }

            } else {
                // Si no se hizo clic en buscar, mostrar todos los productos
                $sql = "SELECT * FROM productos";
            }

            // Ejecutar la consulta
            $result = $conexion->query($sql);

            if (!$result) {
                die("Error en la consulta: " . $conexion->error);
            }
        ?>

        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="item" 
                    data-id="<?= htmlspecialchars($row['id']) ?>" 
                    data-title="<?= htmlspecialchars($row['titulo']) ?>" 
                    data-price="<?= htmlspecialchars($row['precio_unitario']) ?>">

                    <figure>
                        <img src="<?= htmlspecialchars($row['imagen']) ?>" alt="<?= htmlspecialchars($row['titulo']) ?>" style="width:150px; height:auto;">
                    </figure>

                    <div class="info-product">
                        <h2 class="name"><?= htmlspecialchars($row['titulo']) ?></h2>
                        <p class="stock"><?= htmlspecialchars($row['condicion']) ?></p>
                        <p class="descripcion"><?= htmlspecialchars($row['descripcion']) ?></p>
                        <p class="price">$<?= htmlspecialchars($row['precio_unitario']) ?></p>
                        
                        <p class="stock"><?= htmlspecialchars($row['cantidad']) ?> disponibles</p>
                        
                        
                        
                        
                        <?php 
            
                            if (isset($_SESSION['id'])){

                                if($usuario == "comprador"){
                                    echo '<button class="btn-add-cart">Añadir al carrito</button>';
                                    
                                }
                                

                            }
                            else{
                                echo '<a href="Usuario/index.php">Iniciar Sesión</a>';
                            }
                            
                        ?>
                      

                        <?php if (isset($_SESSION['id']) && $_SESSION['id'] == $row['id_usuario']): ?>
                            <div class="acciones">
                                <form action="editar_producto.php" method="GET" style="display:inline;">
                                    <input type="hidden" name="id_producto" value="<?= $row['id'] ?>">
                                    <!--<button type="submit">Editar</button>-->
                                    <a href="editar_producto.php?id=<?php echo $row['id']; ?>" type="submit" class="btn-editar">Editar</a>
                                </form>

                                

                                <form action="eliminar_producto.php" method="POST" style="display:inline;" onsubmit="return confirmarEliminacion(this)">
                                    
                                    <!--<button type="submit" style="background-color:red; color:white;">Eliminar</button>-->
                                    <input type="hidden" name="id_producto" value="<?= $row['id'] ?>">
                                    <a href="eliminar_producto.php?id=<?php echo $row['id']; ?>" type="submit" class="btn-eliminar">Eliminar</a>                                
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No se encontraron productos con los filtros seleccionados.</p>
        <?php endif; ?>
    </div>


 
      <script src="https://sdk.mercadopago.com/js/v2"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  let cart = [];

  const cartModal = document.getElementById("cart-modal");
  const cartItems = document.getElementById("cart-items");
  const totalAmount = document.getElementById("total-amount");
  const openCartBtn = document.getElementById("open-cart-btn");
  const closeCartBtn = document.querySelector(".close-cart");
  const finalizarCompraBtn = document.getElementById("finalizar-compra");

  // Botón de MercadoPago
  const walletContainer = document.createElement("div");
  walletContainer.id = "wallet_container";
  finalizarCompraBtn.insertAdjacentElement("afterend", walletContainer);

  // Agregar producto al carrito
  document.querySelectorAll(".btn-add-cart").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const item = e.target.closest(".item");
      const title = item.dataset.title;
      const price = parseFloat(item.dataset.price);

      const existing = cart.find((p) => p.title === title);
      if (existing) existing.quantity++;
      else cart.push({ title, price, quantity: 1 });

      renderCart();
    });
  });

  // Mostrar carrito
  openCartBtn.addEventListener("click", openCart);
  closeCartBtn.addEventListener("click", closeCart);

  // Renderizar contenido del carrito
  function renderCart() {
    cartItems.innerHTML = "";
    let total = 0;

    cart.forEach((p, i) => {
      total += p.price * p.quantity;
      const div = document.createElement("div");
      div.classList.add("cart-item");
      div.innerHTML = `
        <span>${p.title}</span>
        <span>x${p.quantity}</span>
        <span>$${(p.price * p.quantity).toLocaleString()}</span>
        <button class="btn-remove" data-index="${i}">X</button>
      `;
      cartItems.appendChild(div);
    });

    totalAmount.textContent = total.toLocaleString();

    document.querySelectorAll(".btn-remove").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        removeFromCart(e.target.dataset.index);
      });
    });
  }

  function removeFromCart(index) {
    cart.splice(index, 1);
    renderCart();
  }

  function openCart() {
    cartModal.style.display = "block";
  }

  function closeCart() {
    cartModal.style.display = "none";
  }

  // === 🛒 FINALIZAR COMPRA CON MERCADO PAGO ===
  finalizarCompraBtn.addEventListener("click", async () => {
    if (cart.length === 0) return alert("Tu carrito está vacío.");

    const productsForPayment = cart.map((p) => ({
      title: p.title,
      quantity: p.quantity,
      unit_price: p.price,
    }));

    try {
      const response = await fetch("http://localhost:3000/create_preference", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: productsForPayment }),
      });

      if (!response.ok) {
        alert("Error del servidor al crear la preferencia.");
        return;
      }

      const data = await response.json();
      console.log("ID de preferencia:", data.id);

      const mp = new MercadoPago("APP_USR-dc316edf-6ae6-4ada-8e4d-46faf9e18e5b", {
        locale: "es-AR",
      });

      walletContainer.innerHTML = ""; // limpiar contenedor previo
      mp.checkout({
        preference: { id: data.id },
        render: {
          container: "#wallet_container",
          label: "Pagar con Mercado Pago",
        },
      });

      // Limpiar carrito después de abrir el pago
      cart = [];
      renderCart();
    } catch (error) {
      console.error("Error al comunicarse con el backend:", error);
      alert("Error al conectar con el servidor.");
    }
  });
});
</script>
                
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   

    <script src="compras.js"></script>
    <script src="3d.js"></script>
    <script src="busquedasa.js"></script>
    <script src="scriptpaginaprincipal.js"></script>
    <script src="carrito.js"></script>
</body>
</html>