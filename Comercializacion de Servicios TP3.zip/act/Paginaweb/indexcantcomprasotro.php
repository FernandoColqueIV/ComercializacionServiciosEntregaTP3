<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <script src="https://sdk.mercadopago.com/js/v2"></script>
    <link rel="stylesheet" href="carross.css">
    <link rel="stylesheet" href="estilopaginaprincipal.css">
    <link rel="stylesheet" href="elementoscompras.css">
   
   
    <title>Tienda</title>
</head>
<body>

    <nav class="navbar">
        <div class="navbar-container">
            <div class="logo-container">
                <a href="http://localhost/Paginaweb/Usuario/logout.php" class="logo">Cerrar sesión</a>
            </div>
            <button class="hamburger" id="hamburger">☰</button>
            <div class="navbar-links" id="navbar-links">
                <a href="indexcantcompras.php">Productos</a>
                <a href="Contactos.html">Contacto</a>
                <a href="producto.html">Agregar Producto</a>
            </div>
        </div>
    </nav>
   
    <div class="BarraCompra">			
        <div id="wallet_container"></div>
        <button class="bottomcarrito" id="bottoncompra">Pagar</button>
        
    </div>

    <input type="text" id="search-input" placeholder="Buscar productos..." />

    <a href="producto.html">Agregar Producto</a>  
    <button id="toggle-cart">🛒 Carro (<span id="cart-count">0</span>)</button>

    <div class="container-items">
        <div class="item" data-price="1000" data-title="Arquero">
            <?php

                $conn = new mysqli("localhost", "root", "", "lab");
                if ($conn->connect_error) {
                    die("Error de conexión: " . $conn->connect_error);
                }

                $result = $conn->query("SELECT * FROM productos");
            ?>

            <?php
                session_start();
                include 'conexion.php';

                // Verificamos si el usuario está logueado
                $idUsuarioSesion = $_SESSION['id'] ?? null;

                // Consultamos todos los productos
                $sql = "SELECT * FROM productos";
                $result = $conexion->query($sql);
            ?>

    <div id="contenedorProductos">
        <?php while($row = $result->fetch_assoc()): ?>
            <div class="item" 
                data-id="<?= htmlspecialchars($row['id_producto']) ?>" 
                data-title="<?= htmlspecialchars($row['nombre']) ?>" 
                data-price="<?= htmlspecialchars($row['precio']) ?>">

                <figure>
                    <img src="<?= htmlspecialchars($row['imagen']) ?>" alt="<?= htmlspecialchars($row['nombre']) ?>" style="width:150px; height:auto;">
                </figure>

                <div class="info-product">
                    <h2 class="name"><?= htmlspecialchars($row['nombre']) ?></h2>
                    <p class="descripcion"><?= htmlspecialchars($row['descripcion']) ?></p>
                    <p class="price">$<?= htmlspecialchars($row['precio']) ?></p>
                    <button class="btn-add-cart">Añadir al carrito</button>

                    <?php if (isset($_SESSION['id']) && $_SESSION['id'] == $row['id_usuario']): ?>
                        <div class="acciones">
                            <form action="editar_producto.php" method="GET" style="display:inline;">
                                <input type="hidden" name="id_producto" value="<?= $row['id_producto'] ?>">
                                <button type="submit">Editar</button>
                            </form>

                            <form action="eliminar_producto.php" method="POST" style="display:inline;" onsubmit="return confirmarEliminacion(this)">
                                <input type="hidden" name="id_producto" value="<?= $row['id_producto'] ?>">
                                <button type="submit" style="background-color:red; color:white;">Eliminar</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>


<?php $conexion->close(); ?>


               
                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="UTF-8">
                    <title>Tienda</title>
                    <link rel="stylesheet" href="estilos.css">
                </head>
                <body>

                <div class="container-items">
                    <?php while($row = $result->fetch_assoc()): ?>
                        <div class="item">
                            <div class="info-product">
                                <h2 class="name"><?= htmlspecialchars($row['nombre']) ?></h2>
                                <p class="descripcion"><?= htmlspecialchars($row['descripcion']) ?></p>
                                <p class="price">$<?= htmlspecialchars($row['precio']) ?></p>
                                <button class="btn-add-cart">Añadir al carrito</button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>

                </body>
                </html>

            </div>
        </div>
    </div>


    <script>

/*
    

        let cart = [];
        const totalAmountEl = document.querySelector('.total-pagar');
        const totalItemsEl = document.getElementById('total-items');


// Agregar productos al carrito
document.querySelectorAll('.btn-add-cart').forEach(button => {
    button.addEventListener('click', (event) => {
        const itemElement = event.target.closest('.item');
        const price = parseFloat(itemElement.getAttribute('data-price'));
        const title = itemElement.getAttribute('data-title');

        const product = { title, price, quantity: 1 };
        const existingProduct = cart.find(item => item.title === title);
        if (existingProduct) {
            existingProduct.quantity += 1;
        } else {
            cart.push(product);
        }

        updateCartSummary();
        renderCartItems();
    });
});

// Actualiza el resumen del carrito
function updateCartSummary() {
    const totalAmount = cart.reduce((acc, product) => acc + (product.price * product.quantity), 0);
    const totalItems = cart.reduce((acc, product) => acc + product.quantity, 0);

    totalAmountEl.innerText = totalAmount.toFixed(2);
    totalItemsEl.innerText = totalItems;
}
    */    

const walletContainer = document.getElementById('wallet_container');
const bottonCompra = document.getElementById('bottoncompra');

bottonCompra.addEventListener('click', async () => {
    if (cart.length === 0) {
        alert('El carrito está vacío. Por favor, añade productos antes de pagar.');
        return;
    }

    const productsForPayment = cart.map(product => ({
        title: product.name,
        quantity: product.quantity,
        unit_price: product.price,
    }));

    try {
        const response = await fetch('http://localhost:3000/create_preference', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ items: productsForPayment }),
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('Error al crear preferencia:', errorText);
            alert('Error del servidor al crear preferencia.');
            return;
        }

        const data = await response.json();

        if (data.id) {
            const mp = new MercadoPago('APP_USR-dc316edf-6ae6-4ada-8e4d-46faf9e18e5b', { locale: 'es_AR' });

            walletContainer.innerHTML = ''; // limpiar antes de renderizar nuevo botón

            mp.checkout({
                preference: { id: data.id },
                render: {
                    container: '#wallet_container',
                    label: 'Pagar con MercadoPago',
                },
            });

            addCloseListener();
        } else {
            alert('Error al generar la preferencia de pago.');
        }
    } catch (error) {
        console.error('Error al comunicarse con el backend:', error);
        alert('Ocurrió un error de conexión con el servidor.');
    }
});

function addCloseListener() {
    const interval = setInterval(() => {
        const modal = document.querySelector('.mercadopago-modal-wrapper');
        if (!modal) {
            clearInterval(interval);
            walletContainer.innerHTML = '';
        }
    }, 4000);
}

       

    </script>
    <script>
        function confirmarEliminacion(form) {
            const confirmar = confirm("¿Estás seguro de que querés eliminar este producto?");
            return confirmar; // true = envía el formulario, false = cancela
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="compras.js"></script>
    <script src="3d.js"></script>
    <script src="busquedasa.js"></script>
    <script src="scriptpaginaprincipal.js"></script>
</body>
</html>
