<?php
    $conexion = new mysqli("localhost", "root", "", "lab");

    if ($conexion->connect_error) {
        echo"<h1>ERROR</h1>";
        die("Error de conexión: " . $conexion->connect_error);
    }

?>
