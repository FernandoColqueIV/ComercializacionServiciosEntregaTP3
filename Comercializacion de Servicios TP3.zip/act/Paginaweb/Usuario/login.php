<?php
    session_start();
    include "db_conn.php"; 

    if (isset($_POST['Mail']) && isset($_POST['Clave'])) {
        $Mail = trim($_POST['Mail']);
        $Clave = trim($_POST['Clave']);

        if (empty($Mail)) {
            header("Location: index.php?error=El Mail es requerido");
            exit();
        } elseif (empty($Clave)) {
            header("Location: index.php?error=La contraseña es requerida");
            exit();
        } else {
            
            $sql = "SELECT * FROM users WHERE Mail = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $Mail);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $row = $result->fetch_assoc();

                if (password_verify($Clave, $row['Clave'])) {
                    
                    $_SESSION['Mail'] = $row['Mail'];
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['tipo'] = $row['tipo'];
                    header("Location: ../index.php");
                    exit();

                } else {
                    header("Location: index.php?error=Ma5555il o contraseña incorrectos");
                    exit();
                }

            } else {
                header("Location: index.php?error=qqqqMail o contraseña incorrectos");
                exit();
            }
        }
    } else {
        header("Location: index.php");
        exit();
    }
?>