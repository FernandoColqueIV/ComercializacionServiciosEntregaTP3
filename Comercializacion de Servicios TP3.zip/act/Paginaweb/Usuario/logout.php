<?php
    // 1. Iniciar o reanudar la sesión.
    session_start();

    // 2. Destruir todas las variables de sesión del array $_SESSION
    session_unset();

    // 3. Destruir la sesión completamente (elimina el archivo de sesión en el servidor)
    session_destroy();

    // 4. Redirigir al usuario a la página de login (o la página principal)
    header("Location: ../index.php");
    exit();
?>