<?php
require_once "/opt/lampp/htdocs/act/Paginaweb/Usuario/db_conn.php";
$error = false;

if (isset($_POST['signup'])) {
    $Nombre = mysqli_real_escape_string($conn, $_POST['Nombre']);
    $Clave = mysqli_real_escape_string($conn, $_POST['Clave']);
    $Mail = mysqli_real_escape_string($conn, $_POST['Mail']);
    $tipo = mysqli_real_escape_string($conn, $_POST['tipo']);
    $Clave_hash = password_hash($Clave, PASSWORD_DEFAULT);
    if (!preg_match("/^[a-zA-Z ]+$/", $Nombre)) {
        $Nombre_error = "Ingrese su nombre correctamente";
        $error = true;
    }

    if (!preg_match("/^[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/", $Mail)) {
        $Mail_error = "Ingrese un correo electrónico válido";
        $error = true;
    }

    if (strlen($Clave) < 8) {
    $Clave_error = "La contraseña debe tener al menos 8 caracteres.";
    $error = true;
    } elseif (!preg_match('/[\'^£$%&*()}{@#~?><>,|=_+!-]/', $Clave)) {
        $Clave_error = "La contraseña debe contener al menos un carácter especial (ej: !@#$%^&*)";
        $error = true;
    }

    if (!$error) {
        $sql = "INSERT INTO users (Nombre, Clave, Mail, tipo) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $Nombre, $Clave_hash, $Mail, $tipo);

        if ($stmt->execute()) {
            header("Location: http://localhost/act/Paginaweb/Usuario/index.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}
?>

<!doctype html>
<html lang="es">
  <head>
    <title>Registro</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="estilopaginadeingreso.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  </head>
  <body>

    <header>
      <a href="../index.php">NeuAndes</a>

      <nav>
          <a href="">Marketplace</a>
          <a href="../about.html">Sobre Nosotros</a>            
      </nav>
    </header>

    <div class="container">

      <div class="form-box">

        <h2>Bienvenido a NeuAndes</h2>
        <p>Compra y vende neumáticos de calidad </p>

        <div class="tabs">
          <a href="index.php" class="tab" id="btn-login" >Iniciar Sesión</a>
          <a class="tab active" id="btn-register">Registrarse</a>
        </div>

        <form id="registerForm" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
          <!-- Campo Nombre -->
          <div class="form-group">
            <label for="name">Nombre Completo</label> 
            <input type="text" id="name" name="Nombre" placeholder="Tu nombre completo" required>
            <span><?php if (isset($Nombre_error)) echo $Nombre_error; ?></span>
          </div>

          <!-- Campo Mail -->
          <div class="form-group">
            <label for="email">Correo Electrónico</label>
            <input type="email" id="email" name="Mail" placeholder="tuemail@ejemplo.com" required>
            <span><?php if (isset($Mail_error)) echo $Mail_error; ?></span>
          </div>

          <!-- Campo Contraseña -->
          <div class="form-group">
            <label for="pass">Contraseña</label>
            <input type="password" id="pass" name="Clave" placeholder="Crea una contraseña segura" required>
            <span><?php if (isset($Clave_error)) echo $Clave_error; ?></span>
          </div>
          
          <label for="tipo">Tipo de Usuario</label>
            <select name="tipo" class="formulario-select">
                <option value="vendedor">Vendedor</option>
                <option value="comprador">Comprador</option>
            </select>
          <!-- Botón de Registro -->
          <button type="submit" name="signup" class="btn-primary">Registrarse</button>
          
        </form>
      </div>
</div>
  </body>
</html>