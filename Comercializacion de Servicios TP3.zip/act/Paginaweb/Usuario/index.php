<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ingreso</title>
    <link rel="stylesheet" href="estilopaginadeingreso.css">
</head>
<body>

    <header>
        <a href="../index.php">NeuAndes</a>

        <nav>
            <a href="">Marketplace</a>
            <a href="../about.html">Sobre Nosotros</a>            
        </nav>
    </header>

   
    <div class="container">
        <div class="form-box">
            <h2>Bienvenido a NeuAndes</h2>
            <p>Compra y vende neumáticos de calidad</p>

            <div class="tabs">
                <button class="tab active" id="btn-login">Iniciar Sesión</button>
                <a class="tab" id="btn-register" href="Registro.php">Registrarse</a>
            </div>       
       
       
            <form id="loginForm" action="login.php" method="post">
                <!-- Mostrar errores si existen -->
                <?php if (isset($_GET['error'])): ?>
                    <p class="error"><?php echo htmlspecialchars($_GET['error']); ?></p>
                <?php endif; ?>

                <!-- Campo para el nombre de usuario -->
               <label for="Mail">Email</label>
                <input type="email" id ="Mail" name="Mail" placeholder="tucorreo@ejemplo.com" required>

                <!-- Campo para la contraseña -->
                <label for="Clave">Contraseña</label>
                <input type="password" id ="Clave" name="Clave" required>

                <!-- Botón de envío -->
                <button type="submit" class="btn-primary">Iniciar Sesión</button>

            </form>

        </div>
    </div>
               

    

</body>
</html>
