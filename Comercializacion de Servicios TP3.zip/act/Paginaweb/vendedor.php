<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="css/styles_vendedor.css">
        <title>Vendedor</title>
    </head>

    <body>

        <header>
            <a href="index.html">NeuAndes</a>

            <nav>
               
                <a href="about.html">Sobre Nosotros</a>
                <a href="#" class="login-btn">Cerrar Sesion</a>                

            </nav>
        </header>

        <main>

            <section>
                <div class="perfil-container">
                    <h2>Mi Perfil</h2>

                    <form action="vendedor.php" method="POST">
                        <label for="email">Email</label>
                        <input type="email" id="email" placeholder="marcos@marcos.com" enabled>

                        <label for="nombre">Nombre Completo</label>
                        <input type="text" id="nombre" placeholder="Marcos">

                        <label for="telefono">Teléfono</label>
                        <input type="tel" id="telefono" placeholder="">

                        <label for="tipo">Tipo de Usuario</label>
                        <select id="tipo">
                            <option value="vendedor">Vendedor</option>
                            <option value="comprador">Comprador</option>
                        </select>

                        <p class="ayuda">Los vendedores pueden publicar y comprar. Los compradores solo pueden comprar.</p>

                        <button type="submit" class="btn-guardar">Guardar Cambios</button>
                    </form>
                </div>
            </section>

            <section class="publicaciones">
                <!--ACÁ VAN LAS PUBLICACIONES DEL VENDEDOR PARA QUE PUEDA EDITARLAS O BORRARLASS-->
            </section>
        </main>

    </body>
</html>
<?php
session_start(); 

include 'conexion.php'; // $conexion

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Verificar que el usuario esté logueado
    if (!isset($_SESSION['id'])) {
        echo "Error: no hay usuario logueado.";
        exit();
    }

    // 2. Recoger datos
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $tipo = $_POST['tipo'];
    $email = $_POST['email']; 
    $id_usuario = $_SESSION['id']; // El "enganche"

    // ------------------------------------------------------------------
    // MEJORA 1: La query "UPSERT" (Guardar Cambios)
    // ------------------------------------------------------------------
    // Intenta INSERTAR. Si la llave (id_usuario) ya existe, ACTUALIZA (UPDATE).
    // Asumo que tu tabla se llama 'perfiles' o 'vendedor' y que 'id_usuario' es UNIQUE
    
    $sql = "INSERT INTO vendedor (nombre, telefono, tipo, id_usuario, email)
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                nombre = VALUES(nombre),
                telefono = VALUES(telefono),
                tipo = VALUES(tipo),
                email = VALUES(email)";

    // ------------------------------------------------------------------
    // MEJORA 2: Prepared Statements (Seguridad)
    // ------------------------------------------------------------------
    $stmt = $conexion->prepare($sql);
    
    if ($stmt === false) {
        die("Error al preparar la consulta: " . $conexion->error);
    }

    // "sssis" = string, string, string, integer, string
    $stmt->bind_param("sssis", $nombre, $telefono, $tipo, $id_usuario, $email);

    // 3. Ejecutar y redirigir
    if ($stmt->execute()) {
        header("Location: indexcantcompras.php");
        exit();
    } else {
        echo "Error al guardar en la base: " . $stmt->error;
    }
    
    $stmt->close();
    $conexion->close();
}
?>