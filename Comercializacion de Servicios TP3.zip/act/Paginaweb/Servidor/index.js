import express from "express";
import cors from "cors";
import { MercadoPagoConfig, Preference } from 'mercadopago';

// Configura tus credenciales de MercadoPago
const client = new MercadoPagoConfig({ accessToken: 'APP_USR-6120968903700924-022623-8e64352b2861dbe1b9d04c24643cfe7d-1700219345' });
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// Ruta para crear la preferencia de pago
app.post("/create_preference", async (request, res) => {
    try {
        console.log("Cuerpo de la solicitud recibido:", request.body);

        if (!request.body.items || request.body.items.length === 0) {
            throw new Error("No se recibieron productos en la solicitud.");
        }

        const body = {
            items: request.body.items.map(product => ({
                title: product.title,
                quantity: product.quantity,
                unit_price: product.unit_price,
                currency_id: "ARS",
            })),
            back_urls: {
    failure: "http://localhost/Paginaweb/Contactos.html",
    pending: "http://localhost/Paginaweb/Contactos.html",
  },
        
        };

        const preference = new Preference(client);
        const result = await preference.create({ body });

        console.log("Preferencia creada, ID:", result.id);

        res.json({
            id: result.id, 
        });
    } catch (error) {
        console.error("Error al crear preferencia:", error);
        res.status(500).json({
            error: "Error al crear preferencia",
            message: error.message,
        });
    }
});

app.listen(port, () => {
    console.log(`El servidor está corriendo en el puerto ${port}`);
});
