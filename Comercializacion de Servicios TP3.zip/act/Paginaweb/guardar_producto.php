<?php
session_start(); // importante para acceder a $_SESSION

include 'conexion.php'; // debe crear $conexion

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Verificar que el usuario esté logueado
    if (!isset($_SESSION['id'])) {
        echo "Error: no hay usuario logueado.";
        exit();
    }

    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $id_usuario = $_SESSION['id']; // ✅ Se toma directamente de la sesión

    // Carpeta donde se guardarán las imágenes
    $carpeta = "uploads/";
    if (!file_exists($carpeta)) {
        mkdir($carpeta, 0777, true);
    }

    // Procesar la imagen
    $nombreImagen = $_FILES['imagen']['name'];
    $rutaTemporal = $_FILES['imagen']['tmp_name'];
    $rutaDestino = $carpeta . basename($nombreImagen);

    // Mover la imagen al directorio final
    if (move_uploaded_file($rutaTemporal, $rutaDestino)) {
        // Insertar en base de datos
        $sql = "INSERT INTO productos (nombre, descripcion, precio, id_usuario, imagen)
                VALUES ('$nombre', '$descripcion', '$precio', '$id_usuario', '$rutaDestino')";

        if ($conexion->query($sql) === TRUE) {
            header("Location: indexcantcompras.php");
            exit();
        } else {
            echo "Error al guardar en la base: " . $conexion->error;
        }
    } else {
        echo "Error al subir la imagen.";
    }

    $conexion->close();
}
?>
