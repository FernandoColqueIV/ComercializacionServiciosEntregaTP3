<?php
session_start();
include_once 'conexion.php';

// 1️⃣ Verificar login
if (!isset($_SESSION['id'])) {
    header("Location: Usuario/login.php");
    exit();
}

$id_usuario_actual = (int)$_SESSION['id'];

// --- CONFIRMAR ELIMINACIÓN (POST) ---
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST['id_producto']) || empty($_POST['id_producto'])) {
        echo "Error: No se proporcionó ID de producto (POST).";
        exit();
    }

    $id_producto = (int)$_POST['id_producto'];

    // ✅ Verificar existencia y permisos
    $sql_check = "SELECT imagen, id_usuario FROM productos WHERE id = ?";
    $stmt_check = $conexion->prepare($sql_check);
    $stmt_check->bind_param("i", $id_producto);
    $stmt_check->execute();
    $resultado = $stmt_check->get_result();

    if ($resultado->num_rows === 0) {
        echo "Error: Producto no encontrado.";
        exit();
    }

    $producto = $resultado->fetch_assoc();

    if ($producto['id_usuario'] != $id_usuario_actual) {
        echo "Error: No tienes permiso para eliminar este producto.";
        exit();
    }

    $ruta_imagen = $producto['imagen'];
    $stmt_check->close();

    // ✅ Eliminar producto
    $sql_delete = "DELETE FROM productos WHERE id = ? AND id_usuario = ?";
    $stmt_delete = $conexion->prepare($sql_delete);
    $stmt_delete->bind_param("ii", $id_producto, $id_usuario_actual);

    if ($stmt_delete->execute()) {
        // ✅ Eliminar imagen (si existe y no es default)
        if (file_exists($ruta_imagen) && basename($ruta_imagen) !== 'default.jpg') {
            unlink($ruta_imagen);
        }

        header("Location: index.php?delete=success");
        exit();
    } else {
        echo "Error al eliminar: " . $stmt_delete->error;
    }

    $stmt_delete->close();
    $conexion->close();
    exit();
}

// --- MOSTRAR CONFIRMACIÓN (GET) ---
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Error: No se proporcionó ID de producto (GET).";
    exit();
}

$id_producto = (int)$_GET['id'];

$sql_get = "SELECT * FROM productos WHERE id = ? AND id_usuario = ?";
$stmt_get = $conexion->prepare($sql_get);
$stmt_get->bind_param("ii", $id_producto, $id_usuario_actual);
$stmt_get->execute();
$resultado = $stmt_get->get_result();

if ($resultado->num_rows === 0) {
    echo "Error: Producto no encontrado o sin permisos.";
    exit();
}

$producto = $resultado->fetch_assoc();
$stmt_get->close();
$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Producto</title>
    <link rel="stylesheet" href="css/styles_publicar.css">
</head>
<body>
<header>
    <a href="index.php">NeuAndes</a>
    <nav>
        <a href="about.html">Sobre Nosotros</a>
        <a href="Usuario/logout.php" class="logout-btn">Cerrar Sesión</a>
    </nav>
</header>

<section class="section-publicar">
    <div class="confirm-container">
        <h2>¿Estás seguro de que quieres eliminar este producto?</h2>

        <p><strong><?php echo htmlspecialchars($producto['titulo']); ?></strong></p>

        <?php if (!empty($producto['imagen'])): ?>
            <img src="<?php echo htmlspecialchars($producto['imagen']); ?>" alt="Imagen del producto">
        <?php endif; ?>

        <p>Esta acción no se puede deshacer.</p>

        <form action="eliminar_producto.php" method="POST">
            <input type="hidden" name="id_producto" value="<?php echo $producto['id']; ?>">
            <div class="buttons">
                <button type="submit" class="btn-danger">Sí, eliminar</button>
                <button type="button" class="btn-secondary" onclick="window.location.href='index.php'">Cancelar</button>
            </div>
        </form>
    </div>
</section>
</body>
</html>
