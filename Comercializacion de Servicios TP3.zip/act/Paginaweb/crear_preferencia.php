<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 🔑 Reemplazá con tu Access Token de prueba (desde https://www.mercadopago.com.ar/developers/panel)
$access_token = 'APP_USR-6120968903700924-022623-8e64352b2861dbe1b9d04c24643cfe7d-1700219345';

if (!isset($_GET['titulo']) || !isset($_GET['precio'])) {
    die("Faltan datos del producto.");
}

$titulo = $_GET['titulo'];
$precio = floatval($_GET['precio']);

// Datos de la preferencia
$data = [
    "items" => [
        [
            "title" => $titulo,
            "quantity" => 1,
            "currency_id" => "ARS",
            "unit_price" => $precio
        ]
    ],
    "back_urls" => [
        "success" => "http://localhost/ACT/Paginaweb/index.php",
        "failure" => "http://localhost/ACT/Paginaweb/index.php"
    ],
    "auto_return" => "approved"
];

// Inicializamos cURL
$ch = curl_init("https://api.mercadopago.com/checkout/preferences");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $access_token",
    "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

// Ejecutamos la llamada
$response = curl_exec($ch);
curl_close($ch);

if ($response === false) {
    die("Error al comunicarse con la API de Mercado Pago.");
}

$result = json_decode($response, true);

// Si todo va bien, redirigimos al checkout
if (isset($result['init_point'])) {
    header("Location: " . $result['init_point']);
    exit;
} else {
    echo "<h2>Error al generar la preferencia</h2>";
    echo "<pre>";
    print_r($result);
    echo "</pre>";
}
?>
