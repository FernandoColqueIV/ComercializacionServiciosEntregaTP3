<?php
$conn = new mysqli("localhost", "root", "", "lab");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM productos");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Productos</title>
    <style>
        .info-product { border: 1px solid #ccc; padding: 10px; margin: 10px; border-radius: 5px; width: 200px; }
    </style>
</head>
<body>
    <h1>Productos</h1>
    <div id="contenedorProductos">
        <?php while($row = $result->fetch_assoc()): ?>
            <div class="info-product">
                <h2 class="name"><?= htmlspecialchars($row['nombre']) ?></h2>
                <p class="descripcion"><?= htmlspecialchars($row['descripcion']) ?></p>
                <p class="price">$<?= htmlspecialchars($row['precio']) ?></p>
                <button class="btn-add-cart">Añadir al carrito</button>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>

<?php $conn->close(); ?>
