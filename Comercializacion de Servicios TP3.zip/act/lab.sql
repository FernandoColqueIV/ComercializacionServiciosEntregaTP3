-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-10-2025 a las 02:48:00
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `lab`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `marca` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `ancho` smallint(6) DEFAULT NULL,
  `perfil` smallint(6) DEFAULT NULL,
  `diametro` smallint(6) DEFAULT NULL,
  `temporada` varchar(50) DEFAULT NULL,
  `condicion` enum('nuevo','usado') NOT NULL DEFAULT 'nuevo',
  `cantidad` int(11) NOT NULL DEFAULT 0,
  `precio_unitario` decimal(10,2) NOT NULL,
  `url_imagen` varchar(1024) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Clave` varchar(255) NOT NULL,
  `Mail` varchar(255) NOT NULL,
  `tipo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `Nombre`, `Clave`, `Mail`, `tipo`) VALUES
(1, 'gabriel', '123123', '123123@gmail.com', ''),
(2, 'GABI', '123123', 'gabrielavalos@gmail.com', ''),
(3, 'Gabriel Avalos', 'Alguien123123', 'mimail@gmail.com', ''),
(12, 'Julianiro', '$2y$10$ePAQ4Wj..4y8ja364K0oB.MZQeeNhZ.rC3wiy1P7tIfK9/FWlDyHC', 'tumail@gmail.com', 'vendedor'),
(13, 'Gabriel', '$2y$10$QIWMGTdQ0a/RSOi6WAZvouAlPjpv4kacPZNo5T0GxROi/jABUGrgu', 'as@gmail.com', 'vendedor'),
(14, 'Gabriel Avalos', '$2y$10$l/F9STAZODJDcudDAqTtmeQg0lG0llyJ/.wuWoieCZZwaXQXimBiK', 'ax@gmail.com', 'vendedor'),
(15, 'Gabriel', '$2y$10$uQLH0.EKkw6BYUqpBuDI8OEbIYGeHFN2tMXGPZ6fdxfG4YAqI5ndq', 'a@gmail.com', 'comprador');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
